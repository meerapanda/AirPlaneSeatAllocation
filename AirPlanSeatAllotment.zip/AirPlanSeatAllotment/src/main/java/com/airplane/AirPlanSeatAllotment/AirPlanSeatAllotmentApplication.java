package com.airplane.AirPlanSeatAllotment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirPlanSeatAllotmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirPlanSeatAllotmentApplication.class, args);
	}

}
