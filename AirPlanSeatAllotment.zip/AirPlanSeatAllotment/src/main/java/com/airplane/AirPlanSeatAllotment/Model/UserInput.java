package com.airplane.AirPlanSeatAllotment.Model;

import org.springframework.stereotype.Service;

@Service
public class UserInput {
    public Integer[][] getSeatArray() {
        return seatArray;
    }

    public void setSeatArray(Integer[][] seatArray) {
        this.seatArray = seatArray;
    }

    Integer [][] seatArray;
    Integer numberOfPassenger;
    public Integer getNumberOfPassenger() {
        return numberOfPassenger;
    }

    public void setNumberOfPassenger(Integer numberOfPassenger) {
        this.numberOfPassenger = numberOfPassenger;
    }


}
