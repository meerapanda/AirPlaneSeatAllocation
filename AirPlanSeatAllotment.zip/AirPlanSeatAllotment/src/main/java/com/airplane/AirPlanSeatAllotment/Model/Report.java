package com.airplane.AirPlanSeatAllotment.Model;

import org.springframework.stereotype.Service;

@Service
public class Report {

}
