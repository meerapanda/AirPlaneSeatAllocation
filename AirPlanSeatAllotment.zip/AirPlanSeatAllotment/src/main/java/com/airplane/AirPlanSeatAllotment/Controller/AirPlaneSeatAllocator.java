package com.airplane.AirPlanSeatAllotment.Controller;


import com.airplane.AirPlanSeatAllotment.Model.UserInput;
import com.airplane.AirPlanSeatAllotment.Service.AirPlaneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("airPlane")
public class AirPlaneSeatAllocator {

    @Autowired
    AirPlaneService airPlaneService;
    @PostMapping("seat")

    public Map<String,String> downloadFileWithPost(@RequestBody UserInput userInput) throws IOException {


        String path =airPlaneService.getSeatAllocation(userInput);
        Map<String,String> response = new HashMap<>();
        response.put("AirPlaneSeatAllocationReport:::",path);
        return response;
    }

}
