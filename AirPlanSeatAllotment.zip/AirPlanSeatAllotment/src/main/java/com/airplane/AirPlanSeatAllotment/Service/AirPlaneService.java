package com.airplane.AirPlanSeatAllotment.Service;

import com.airplane.AirPlanSeatAllotment.Model.UserInput;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AirPlaneService {
public String getSeatAllocation(UserInput userInput) throws IOException {
    Integer[][]a = userInput.getSeatArray();
    int count = userInput.getNumberOfPassenger();
    int total=1;
    List<Integer[][]> arr = new ArrayList<>();
    for(int i=0;i<a.length;i++)
    {

        int x= a[i][0];
        int y=a[i][1];
        arr.add(new Integer[x][y]);

    }

    for(int k=0;k<arr.size();k++){
        for(int i=0;i<arr.get(k).length;i++)
        {
            for(int j=0;j<arr.get(k)[i].length;j++)
            {
                arr.get(k)[i][j]=0;
            }
        }
    }
    while(count !=0) {
        for (int m=0; m<arr.size();m++) {

            for (int i=0; i<arr.get(m).length;i++) {
                for (int k = 0; k < arr.size()-1; k++) {

                    try {
                        int j = arr.get(k)[i].length - 1;
                        if (arr.get(k)[i][j] == 0 && total <=count) {
                            arr.get(k)[i][j] = total;
                            total++;
                        }
                    }catch (ArrayIndexOutOfBoundsException e){
                        continue;
                    }


                }
                try {
                    if (arr.get(arr.size()-1)[i][0] == 0 && total <=count) {
                        arr.get(arr.size()-1)[i][0] = total;
                        total++;
                    }
                }catch (ArrayIndexOutOfBoundsException e){
                    continue;
                }
                for (int k = 1; k < arr.size() - 1; k++) {

                    try {
                        if (arr.get(k)[i][0] == 0 && total <=count) {
                            arr.get(k)[i][0] = total;
                            total++;
                        }
                    }catch (ArrayIndexOutOfBoundsException e){
                        continue;
                    }


                }
                try {
                    if (arr.get(0)[i][0] == 0 && total <=count) {
                        arr.get(0)[i][0] = total;
                        total++;
                    }
                    if (arr.get(arr.size()-1)[i][arr.get(arr.size()-1)[i].length - 1] == 0 && total <=count) {
                        arr.get(arr.size()-1)[i][arr.get(arr.size()-1)[i].length - 1] = total;
                        total++;
                    }
                }catch (ArrayIndexOutOfBoundsException e){
                    continue;
                }
                for (int k = 0; k < arr.size() ; k++) {

                    try {
                        for (int j = 0; j < arr.get(k)[i].length; j++) {
                            if (arr.get(k)[i][j] == 0 && total <= count) {
                                arr.get(k)[i][j] = total;
                                total++;
                            }
                        }
                    }catch (ArrayIndexOutOfBoundsException e){
                        continue;
                    }


                }

            }
        }

        count--;
    }
    //Create blank workbook
    XSSFWorkbook workbook = new XSSFWorkbook();

    //Create a blank sheet
    XSSFSheet spreadsheet = workbook.createSheet( " AirPlanSeatArrangement ");

    //Create row object
    XSSFRow row;
    int rowid = 0;


    for(int k=0;k<arr.size();k++){

        row = spreadsheet.createRow(rowid++);
            int cellid =0;


        for(int i=0;i<arr.get(k).length;i++)
        {
            for (int j = 0; j < arr.get(k)[i].length; j++) {
                Cell cell = row.createCell(cellid++);
                cell.setCellValue(arr.get(k)[i][j]);



            }
            cellid =0;
            row = spreadsheet.createRow(rowid++);

        }


    }
    String path = System.getProperty("user.home") + File.separator + "AirPlaneSeatAllocation.xlsx";
    FileOutputStream out = new FileOutputStream(
            new File(path));

    workbook.write(out);
    out.close();
     return path;
}
}
